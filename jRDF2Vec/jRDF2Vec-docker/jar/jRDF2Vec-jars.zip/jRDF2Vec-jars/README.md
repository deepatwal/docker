# jRDF2vec | Current JAR Files
In this branch, you will find the JAR file of the latest (successful) commit automatically pushed to the [jars directory](/jars). 

